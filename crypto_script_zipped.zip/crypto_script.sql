create database capstone_project;
use capstone_project;
select * from cryptopunkdata;
drop database capstone_project;
select distinct(name) from cryptopunkdata;

create database capstone_project;
use capstone_project;
select * from cryptopunkdata;

-- How many sales occurred during this time period? 

select count(token_id) from cryptopunkdata order by token_id;

-- Return the top 5 most expensive transactions (by USD price) for this data set. Return the name, ETH price, and USD price, as well as the date.

select name,eth_price,usd_price,day from cryptopunkdata order by usd_price desc limit 5;


-- Return all the NFT names and their average sale price in USD. Sort descending. Name the average column as average_price.

select name,avg(usd_price) as average_price from cryptopunkdata group by name order by average_price desc;


-- Return each day of the week and the number of sales that occurred on that day of the week, as well as the average price in ETH. Order by the count of transactions in ascending order.
select dayofweek(day),count(*),avg(eth_price) from cryptopunkdata
group by dayofweek(day) order by count(*) ;


-- Construct a column that describes each sale and is called summary. The sentence should include who sold the NFT name, who bought the NFT, who sold the NFT, the date, and what price it was sold for in USD rounded to the nearest thousandth.
-- Here’s an example summary:
--  “CryptoPunk #1139 was sold for $194000 to 0x91338ccfb8c0adb7756034a82008531d7713009d from 0x1593110441ab4c5f2c133f21b0743b2b43e297cb on 2022-01-14”

select
  (concat(name,"  was sold for $ ",round(usd_price,-2)," to ",ï»¿buyer_address," from ",seller_address," on ",day)) as summary
  from cryptopunkdata;
  
  --  Create a view called “1919_purchases” and contains any sales where “0x1919db36ca2fa2e15f9000fd9cdc2edcf863e685” was the buyer.

create view 1919_purchases as
  select * from cryptopunkdata
  where ï»¿buyer_address='0x1919db36ca2fa2e15f9000fd9cdc2edcf863e685';


-- Create a histogram of ETH price ranges. Round to the nearest hundred value. 

select
   ROUND(eth_price,-2) as bucket,
   COUNT(*) as count,
   rpad('',count(*),'*') as bar
   from cryptocryptopunkdatapunkdata
   group by bucket
   order by bucket;

-- Return a unioned query that contains the highest price each NFT was bought for and a new column called status saying “highest” with a query that has the lowest price each NFT was bought for and the status column saying “lowest”. The table should have a name column, a price column called price, and a status column. Order the result set by the name of the NFT, and the status, in ascending order. 

select name,max(eth_price) as price,'highest' as status
from cryptopunkdata
group by name
union
select name,min(eth_price) as price,'lowest' as status
from cryptopunkdata
group by  name
order by name;


-- What NFT sold the most each month / year combination? Also, what was the name and the price in USD? Order in chronological format. 


SELECT 
    name,
    usd_price,
    sale_year,
    sale_month,
    sale_count,
    ranked_in_month
FROM (
    SELECT 
        name,
        MAX(usd_price) as usd_price,
        YEAR(day) AS sale_year,
        MONTH(day) AS sale_month,
        COUNT(*) AS sale_count,
        DENSE_RANK() OVER (PARTITION BY YEAR(day), MONTH(day) ORDER BY COUNT(*) DESC) as ranked_in_month
    FROM
        cryptopunkdata
    GROUP BY name, YEAR(day), MONTH(day)
) as dt
WHERE ranked_in_month = 1;

-- Return the total volume (sum of all sales), round to the nearest hundred on a monthly basis (month/year).

select month(day) as month_of_day,year(day) as year_of_day,round(sum(eth_price),-2) as total_volume  from cryptopunkdata
group by  month_of_day, year_of_day
order by  year_of_day, month_of_day;

select month(day) as month_of_day,year(day) as year_of_day,round(sum(eth_price),-2) as total_volume  from cryptopunkdata
group by  month_of_day, year_of_day
order by  month_of_day, year_of_day;

-- Count how many transactions the wallet "0x1919db36ca2fa2e15f9000fd9cdc2edcf863e685"had over this time period.

select count(*) as no_of_sales from cryptopunkdata where  ï»¿buyer_address = "0x1919db36ca2fa2e15f9000fd9cdc2edcf863e685";


-- Create an “estimated average value calculator” that has a representative price of the collection every day based off of these criteria:
--  - Exclude all daily outlier sales where the purchase price is below 10% of the daily average price
--  - Take the daily average of remaining transactions
--  a) First create a query that will be used as a subquery. Select the event date, the USD price, and the average USD price for each day using a window function. Save it as a temporary table.
--  b) Use the table you created in Part A to filter out rows where the USD prices is below 10% of the daily average and return a new estimated value which is just the daily average of the filtered data.

 create temporary table temp_table(
 select day,usd_price,avg(usd_price)  over(partition by day) as average_usd_price from cryptopunkdata)
 ;
 select * from temp_table;
 
 select * from temp_table  where usd_price < .1* average_usd_price;


